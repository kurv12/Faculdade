package exceptionHandling;

public class InvalidPositionException extends Exception{  // Checada
	// getMessage()
	// printStackTrace()
	// toString()
	public InvalidPositionException(String msg) {
		super(msg);
	}
}
