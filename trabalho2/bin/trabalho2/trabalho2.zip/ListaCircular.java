/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho2;

/**
 *
 * @author Keven
 */
public class ListaCircular implements Lista {

    Node head;

    //Insere em determinada posição
    @Override
    public boolean insert(int pos, Object obj) {
        if (contains(obj)) {
            System.out.println("Já contém este objeto!");
            return false;
        } else {

            Node novoNo = new Node(obj), aux = head;
            int count = 0;

            if (pos == 0) {
                return insert(obj);
            } else if (pos > 0 && pos < size() - 1) {
                while (count < pos - 1) {
                    aux = aux.getNext();
                    count++;
                }
                novoNo.setNext(aux.getNext());
                aux.setNext(novoNo);
                return true;
            } else if (pos == size() - 1) {
                insertLast(obj);
                return true;
            } else {
                return false;
            }
        }
    }

    //Insere na cabeça ou topo
    @Override
    public boolean insert(Object obj) {
        if (contains(obj)) {
            System.out.println("Já contém este objeto!");
            return false;
        } else {
            Node novoNo = new Node(obj);
            novoNo.setNext(head);
            head = novoNo;
            return true;
        }
    }

    //Insere na ultima posição
    @Override
    public boolean insertLast(Object obj) {
        if (contains(obj)) {
            System.out.println("Já contém este objeto!");
            return false;
        } else {
            Node novoNo = new Node(obj);
            Node aux = head;

            if (!isEmpty()) {
                while (aux.getNext() != head) {
                    aux = aux.getNext();
                }
                aux.setNext(novoNo);
                novoNo.setNext(head);
                return true;
            } else {
                return false;
            }
        }
    }

    //Remove em uma determinada posição
    @Override
    public boolean remove(int pos) {
        int count = 1;
        Node aux;

        if (pos == 0 || pos == 1) {
            head = head.getNext();
        } else if (pos > 1 && pos <= size()) {
            aux = head;
            while (count < pos - 1) {
                aux = aux.getNext();
                count++;
            }
            Node aux1 = aux.getNext();
            aux.setNext(aux1.getNext());
            return true;
        }
        return false;
    }

    //remove o ultimo da lista
    @Override
    public Object removeLast() {
        Node aux = head;
        Node aux1 = head.getNext();

        if (!isEmpty()) {
            while (aux1.getNext() != head) {
                aux = aux.getNext();
                aux1 = aux1.getNext();
            }
            aux.setNext(head);
        }
        return aux;
    }

    //Remove do topo da lista
    @Override
    public Object remove() {
        Node aux = head;
        head = head.getNext();
        return aux.getItem();
    }

    //Verifica se está vazio;
    @Override
    public boolean isEmpty() {
        return head == null;
    }

    //Calcula tamanho da lista
    @Override
    public int size() {
        int tamanho = 0;
        Node aux;
        if (!isEmpty()) {
            aux = head;
            tamanho = 1;
            while (aux.getNext() != head) {
                aux = aux.getNext();
                tamanho++;
            }
        }
        return tamanho;
    }

    //Retorna um item em posição especifica
    @Override
    public Object peek(int pos) {
        int count = 0;
        Node aux;

        if (pos == 1) {
            return head.getItem();
        } else if (pos > 1 && pos <= size()) {
            aux = head;
            while (count < pos - 1) {
                aux = aux.getNext();
                count++;
            }
            return aux.getItem();
        } else {
            return null;
        }
    }

    @Override
    public void sort() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    //Inverte lista circular
    @Override
    public void invert() {
        Node aux = head;
        Node headinvert = new Node();
        headinvert.setItem(aux.getItem());
        headinvert.setNext(head);
        int count = 0;
        while (count < size() - 1) {
            aux = aux.getNext();
            Node aux2 = new Node();
            aux2.setItem(aux.getItem());
            aux2.setNext(headinvert);
            headinvert = aux2;
            count++;
        }
        head = headinvert;
    }

    @Override
    public Lista getFirstHalf() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Lista getSecondHalf() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    //Vê se contem objeto
    @Override
    public boolean contains(Object obj) {
        int count = 0;
        Node aux;
        boolean contain = false;

        if (!isEmpty()) {
            aux = head;
            while (count < size()) {
                if (aux.getItem().equals(obj)) {
                    contain = true;
                }
                aux = aux.getNext();
                count++;
            }
        }
        return contain;
    }

    //Imprime lista
    @Override
    public String toString() {
        Node aux = head;
        int count = 0;
        String resultado = "Lista = ";
        while (count < size()) {
            resultado = resultado + " " + aux.getItem();
            aux = aux.getNext();
            count++;
        }
        return resultado;
    }

}
