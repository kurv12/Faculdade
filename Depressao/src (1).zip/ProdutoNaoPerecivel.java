public class ProdutoNaoPerecivel extends Produto{

	public ProdutoNaoPerecivel() {
		
	}
	
	public ProdutoNaoPerecivel(int codigo, String nome, Fornecedor fornecedor, float precoDeCusto, float precoFinal,
			String apelido, Estoque estoque) {
		super(codigo, nome, fornecedor, precoDeCusto, precoFinal, apelido, estoque);
	}
	
}
