public class FornecedorOcasional extends Fornecedor {

	public FornecedorOcasional(String nome, String endereco, String cnpj) {
		super(nome, endereco, cnpj);
	}
	
}
