import java.util.Date;

public class ProdutoPerecivel extends Produto {

	protected Date dataValidade;

	public Date getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(Date dataValidade) {
		this.dataValidade = dataValidade;
	}

	public ProdutoPerecivel() {
		
	}
	
	public ProdutoPerecivel(int codigo, String nome, Fornecedor fornecedor, float precoDeCusto, float precoFinal,
			String apelido, Estoque estoque) {
		super(codigo, nome, fornecedor, precoDeCusto, precoFinal, apelido, estoque);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
